var appBaseUrl = 'chrome-extension://icnlmeafeacofpkfbaaphcknoclngkdh';
var installationType = 'app';

var config = {
	appUrl: appBaseUrl + '/index.html',
	loginUrl: '/unhosted/login.html',
	callbackUrl: appBaseUrl + '/unhosted/callback.html',
	clientId: appBaseUrl,
	dataScope: 'myfavouritesandwich.org',
};
